To install copy the hmne_addfiles.dll file to the HM NIS Edit plugins directory ($PROGRAMFILES\HM Soft\NisEdit\Plugins) and restart HM NIS Edit.
You will find a new item under the Tools menu.
