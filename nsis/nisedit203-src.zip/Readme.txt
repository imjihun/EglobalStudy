This version of HM NIS Edit is designed to work with NSIS 2.x please download and  install it before install HM NIS Edit download NSIS 2.x at http://nsis.sourceforge.net/

